const appiKey = 'b1fc8d07a9151e4b6223c30334edf09e';


window.addEventListener('load', function(){

cargarSelectCiudades();
document.getElementById('selCiudades').addEventListener('change', traerPronostico);
//document.getElementById('btnRecargar').addEventListener('click', traerPronosticoCity);
});

function cargarSelectCiudades (){
    traerCiudades();
   
}

function traerCiudades(){

    //ajax al json de city.list
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if (xhr.readyState == 4){
            if(xhr.status == 200){
                // aca va el codigo que se ejecuta cuando la peticion termino y es correcta
                let datos = JSON.parse(xhr.responseText);
                let ciudades = parsearArgentinas(datos);
                
                actualizarSelect(ciudades);              
            
            }
            else{
                // aca va el código que se ejecuta cuando se produjo un error en la peticion
                console.error (xhr.status + ' : ' + xhr.statusText);
            
            }

        }
        else{
            // aca va el codigo que se ejecuta mientras se esta procesando la peticion (spinner)
            
        }
    }
    xhr.open('GET',  './city.list.json', true);   

    xhr.send();

}

function parsearArgentinas (arr){ //arr es el parametro que recibe lo que pasaste en la llamada

return arr.filter(ciudad=> ciudad.country === "AR")
   .map(function(ciudad){

    return {id: ciudad.id, nombre: ciudad.name + ", " + ciudad.country} //contruimos un objeto que tiene dos campos el id y el nombre 
    // otra version es .map (ciudad => { id: ciudad.id, nombre: ciudad.name + ", " + ciudad.country})

   })

}

function traerPronostico(){
    let divActualizacion = document.getElementById('act');

    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if (xhr.readyState == 4){
            if(xhr.status == 200){
                // aca va el codigo que se ejecuta cuando la peticion termino y es correcta
                let pronostico = JSON.parse(xhr.responseText);
                
               // document.getElementById('info').innerText = xhr.responseText;     
                actualizarPronostico(pronostico);
                
            }
            else{
                // aca va el código que se ejecuta cuando se produjo un error en la peticion
                console.error (xhr.status + ' : ' + xhr.statusText);
            }
        }
        else{
            // aca va el codigo que se ejecuta mientras se esta procesando la peticion (spinner)
            divActualizacion.innerHTML = '<img src="./images/anemometro.gif" />';
        }
    }
    xhr.open('GET', armarURL(), true);   //va com () porque lo que pido es el return de la funcion

    xhr.send();

}

function actualizarSelect(ciudades){
let selCiudades = document.getElementById('selCiudades');
    for (ciudad of ciudades){
        let opcion = document.createElement('option');
        opcion.setAttribute('value', ciudad.id);
        let texto = document.createTextNode(ciudad.nombre);
        opcion.appendChild(texto);
        selCiudades.appendChild(opcion);
    }
}


function armarURL() {
    let idCiudad = document.getElementById('selCiudades').value;
    let url = "http://api.openweathermap.org/data/2.5/weather?id=" + idCiudad + "&lang=es&units=metric&APPID=" + appiKey;

    return url;
}

function actualizarPronostico (pronostico){
    document.getElementById('temperatura').innerText = "Temperatura: " + parseInt (pronostico.main.temp).toFixed(1) + " ºC";
    document.getElementById('humedad').innerText = "Húmedad: " + pronostico.main.humidity + " %";
    document.getElementById('presion').innerText = "Presión: " + pronostico.main.pressure + " hPa";
    document.getElementById('viento').innerText = "Viento: " + parseInt (pronostico.wind.speed * 3.6).toFixed(0) + " Km/h";
    document.getElementById('descripcion').innerText = "Se espera " + pronostico.weather[0].description;
    document.getElementById('minmax').innerText = "Máxima: " + (pronostico.main.temp_max).toFixed(1) + " ºC " + " - Mínima: " + (pronostico.main.temp_min).toFixed(1) + " ºC";
    document.getElementById('imagen').setAttribute('src', "http://openweathermap.org/img/w/" + pronostico.weather[0].icon + ".png" );
    document.getElementById('imagen').setAttribute('style', 'width:90px' );
    document.getElementById('ciudad').innerText = pronostico.name + ", " + pronostico.country;
    let fecha = traerFecha();
    document.getElementById('act').innerText = fecha.toLocaleDateString() + " " + fecha.toLocaleTimeString();
}

function traerFecha(){
    let fecha = new Date();
    return fecha;
    
}